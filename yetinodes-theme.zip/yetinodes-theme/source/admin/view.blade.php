<div class="box box-success">
  <div class="box-header with-border"><h3 class="box-title">YetiNodes Theme</h3></div>
  <div class="box-body">
    <p>YetiNodes theme is active. Edit the colour variables at the top of
    <code>dashboard/style.css</code> and <code>admin/style.css</code> to change the gradient palette, then reinstall.</p>
  </div>
</div>
