YetiNodes Theme (Blueprint extension)
Install:
  cd /var/www/pterodactyl
  # upload yetinodestheme.blueprint here, then:
  blueprint -install yetinodestheme
Remove:  blueprint -remove yetinodestheme
