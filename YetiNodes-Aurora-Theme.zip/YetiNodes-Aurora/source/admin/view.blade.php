<div class="box box-success">
  <div class="box-header with-border"><h3 class="box-title">YetiNodes Aurora</h3></div>
  <div class="box-body"><p>Theme active. Change the colours via the <code>--y-*</code> variables at the top of the CSS files.</p></div>
</div>
