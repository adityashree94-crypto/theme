YetiNodes Aurora v1.1.0
cd /var/www/pterodactyl
blueprint -remove yetinodestheme   # old version (ignore if not installed)
blueprint -install yetinodesaurora
